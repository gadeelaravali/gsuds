package com.capg.cms.ui;
import java.util.Scanner;

import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;
import com.capg.cms.service.CustomerServiceImp;
public class Client {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerServiceImp service = new CustomerServiceImp();
		Customer bean = new Customer(null,null,0,null,0,null);
		while (true) {
			System.out.println("WELCOME TO CUSTOMER MANAGMENT");
			System.out.println("-------------------------------------");
			System.out.println("1.ADD CUSTOMER");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT AMOUNT");
			System.out.println("4.WITHDRAW AMOUNT");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.println("-------------------------------------");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			switch (choice) {
			case 1:				
				boolean validname=false;
				do{					
				System.out.println("ENTER CUSTOMER FIRST NAME");
				String cname = sc.next();
				validname = service.validateName(cname);			
				}while(!validname);
				System.out.println("ENTER CUSTOMER MOBILENO");
				String mobileno = sc.next();
				System.out.println("ENTER CUSTOMER PANNO");
				String panno = sc.next().toUpperCase();
				System.out.println("ENTER CUSTOMER AGE");
				int age = sc.nextInt();
				System.out.println("ENTER CUSTOMER ADDR");
				StringBuffer addr = new StringBuffer();
				System.out.println("ENTER HOUSE NO");
				StringBuffer addr1 = new StringBuffer();
				//String s = addr.next();
				//addr.append(sc.next());
				addr1.append(sc.next());
				System.out.println("ENTER STREET NAME");
				StringBuffer addr2 = new StringBuffer();
				addr2.append(sc.next());
				System.out.println("ENTER CITY NAME");
				StringBuffer addr3 = new StringBuffer();
				addr3.append(sc.next());
				System.out.println("ENTER STATE NAME");
				StringBuffer addr4 = new StringBuffer();
				addr4.append(sc.next());
				System.out.println("ENTER PINCODE");
				StringBuffer addr5 = new StringBuffer();
				addr5.append(sc.next());			
				addr.append(","+addr1).append(","+addr2).append(","+addr3).append(","+addr4);
				System.out.println("ENTER BALANCE"); 
				 int amt = sc.nextInt();
			
				 //boolean isValid = service.validateData(bean);
				//String phno = sc.next();
				/*boolean isvalid = service.validateAccno(accno);
				if (isvalid) {*/
							
						boolean validphno = service.validatePhno(mobileno);	
						boolean validage = service.validateAge(age);	
						boolean validpan = service.validatePan(panno);
						//boolean validAddr = service.validateAddr(addr);
							boolean isAdded = service.addCustomer(bean);
							if (validname && validphno && isAdded && validage && validpan /*&&validAddr*/) 
							{
								System.out.println("added successfully");
								System.out.println(bean);
							} else
								System.out.println("not added");
							break;
			case 2:
				System.out.println("ENTER ACCNO TO GET BALANCE");
				int id1 = sc.nextInt();				
				if(id1!=0)
				{
				boolean validaccno = service.validateAccno(id1);
				if (validaccno) {	
					System.out.println("ENTER PIN");
					int id2=sc.nextInt();
					boolean validpinno = service.validatePinno(id2);
					if(validpinno)
					{									
				Customer c = service.displayCustomer(id1,id2);
				//	service.displayCustomer(id);
				//	c=service.displayCustomer(id1,id2))
						//System.out.println(c);
					}
				}
				else
				{
					System.out.println("ENTER VALID PIN FOR YOUR ACCOUNT");
				}
				}
				
				else {	
						try {
							throw new CustomerNotFound("ENTER VALID ACCOUNT");
						} catch (CustomerNotFound e) {
							// TODO: handle exception
							e.printStackTrace();
					//	}					
					}			
				}
				break;							/*	}
						
					else System.err.println("plz enter correct data");*/						  
				/*	}						 
						else
							System.out.println("invalid mobile num");
					} else
						System.out.println("invalid name");*/
				/*}else
					System.out.println("invalid account num");					
					}				
				break;	*/		
			  case 3: System.out.println("ENTER ACCNO TO DEPOSIT");
				int id3 = sc.nextInt();				
				if(id3!=0)
				{
				boolean validaccno = service.validateAccno(id3);
				if (validaccno) {	
					System.out.println("ENTER PIN");
					int id4=sc.nextInt();
					boolean validpinno = service.validatePinno(id4);
					if(validpinno)
					{	
				  System.out.println("ENTER AMOUNT TO DEPOSIT");
				  int da = sc.nextInt();
				 // Customer c = new Customer();
				  Customer a=service.displayCust(id3);
				 service.depositAmt(da,a);	
				//  System.out.println("a0" + service.depositAmt(da,a)	);
				 // System.out.println("deposit done successfully");
			/*	  int a=c.getAmt();
				  System.out.println("balance is:"+a);*/
			//	  Customer c1= service.withDraw(id3,id4);
					}
					else
						System.out.println("PLEASE ENTER CORRECT PIN");
				}
				else
				{
				try {
					throw new CustomerNotFound("ENTER VALID ACCOUNT");
				} catch (CustomerNotFound e) {
					// TODO: handle exception
					e.printStackTrace();	
				}
				}
				}
			  break;
			  case 4:
				  System.out.println("ENTER ACCNO TO WITHDRAW");
					int id5 = sc.nextInt();				
					if(id5!=0)
					{
					boolean validaccno = service.validateAccno(id5);
					if (validaccno) {	
						System.out.println("ENTER PIN");
						int id6=sc.nextInt();
						boolean validpinno = service.validatePinno(id6);
						if(validpinno)
						{	
					  System.out.println("ENTER AMOUNT TO WITHDRAW");
					  int wd = sc.nextInt();
					  Customer c = service.withDraw(id5,id6,wd);
					  
					  System.out.println("WITHDRAW DONE SUCCESSFULLY");
						}
						else
							System.out.println("ENTER VALID PIN FOR YOUR ACCOUNT");
					}
					else
					{
					try {
						throw new CustomerNotFound("ENTER VALID ACCOUNT");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						e.printStackTrace();
				}		
					}
					}
			  break; 
			  case 5:System.out.println("ENTER YOUR ACCOUNT NUMBER");			  
				int id7 = sc.nextInt();		
				boolean validaccno = service.validateAccno(id7);
				Customer c = service.displayCust(id7);
				if(id7!=0)
				{		
				System.out.println("ENTER PIN");
				int id8=sc.nextInt();
				boolean validpinno = service.validatePinno(id8);
				if((c.getAccno()==id7)&&(c.getPin()==id8)){				
				System.out.println("ENTER  ACCOUNT NUMBER TO TRANSFER");				  
				int id9 = sc.nextInt();	
				if(id9!=0)
				{
				boolean validaccno2 = service.validateAccno(id9);
				if (validaccno) {			
					System.out.println("ENTER AMOUNT TO TRANSFER");
					int at = sc.nextInt();	
					Customer b=service.displayCust(id9);
					 //Customer c = service.displayCust(id7);
					 boolean z=service.fundTransfer(c, b, at, id7, id9, id8);
					 if(z){
					 System.out.println("BALANCE IN YOUR ACCOUNT"+c.getAmt());
						System.out.println("BALANCE IN OTHER ACCOUNT"+b.getAmt());
				}else{
					System.out.println("TRANSACTION FAILED");}
				}
				else{
					try {
						throw new CustomerNotFound("ENTER VALID ACCOUNT TO TRANSFER");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						e.printStackTrace();
				}		
					
				}
				}else{
					try {
						throw new CustomerNotFound("ENTER VALID ACCOUNT TO TRANSFER");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						e.printStackTrace();
				}		
				}
				}else{
					try {
						throw new CustomerNotFound("ENTER VALID PIN FOR YOUR ACCOUNT");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						e.printStackTrace();
				}
				}
				}else{
					try {
						throw new CustomerNotFound("YOUR ACCOUNT NUMBER IS NOT CORRECT");
					} catch (CustomerNotFound e) {
						// TODO: handle exception
						e.printStackTrace();
				}	
				}
				break;
		 /* case 6:
			  System.out.println("print transactions");
			 service.printTransactions(); 
			 break; 
			 case 7: System.exit(0);
			 break;
				*/
		
			default:
			/*	System.out.println("displayig all details");
				service.displayAll();*/
				break;
		}
	
	}

}
}
