package com.capg.cms.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transactions")

public class Transaction {
@Id
private int tranid;
private String Transaction;
	
}
